param ($HelloworldPath, $ResultPath)
$CmdText =  "& ""$HelloworldPath"" ""$ResultPath"""
Invoke-Expression $CmdText
 
