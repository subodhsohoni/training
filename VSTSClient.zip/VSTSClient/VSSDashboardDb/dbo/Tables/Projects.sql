﻿CREATE TABLE [dbo].[Projects] (
    [ProjectName]    NVARCHAR (MAX) NOT NULL,
    [SubscriptionId] NVARCHAR (MAX) NOT NULL,
    [PAT]            NVARCHAR (MAX) NOT NULL
);

