﻿CREATE TABLE [dbo].[ChangesetsData] (
    [PROJNAME]       NVARCHAR (MAX) NOT NULL,
    [DATE]           DATE           NOT NULL,
    [CSWOWI]         SMALLINT       NOT NULL,
    [SUBSCRIPTIONID] NVARCHAR (MAX) NULL
);

