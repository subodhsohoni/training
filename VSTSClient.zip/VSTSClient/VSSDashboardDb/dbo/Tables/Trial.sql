﻿CREATE TABLE [dbo].[Trial] (
    [Date] DATETIME      NOT NULL,
    [Name] NVARCHAR (50) NOT NULL
);

