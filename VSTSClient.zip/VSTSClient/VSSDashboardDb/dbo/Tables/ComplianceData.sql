﻿CREATE TABLE [dbo].[ComplianceData] (
    [PROJNAME]       NVARCHAR (MAX) NOT NULL,
    [CURIT]          NVARCHAR (MAX) NOT NULL,
    [AREA]           NVARCHAR (MAX) NOT NULL,
    [OPENREQ]        SMALLINT       NULL,
    [ORWOACCCR]      SMALLINT       NULL,
    [ORWOTASKS]      SMALLINT       NULL,
    [OPENTASKS]      SMALLINT       NULL,
    [ORPHANS]        SMALLINT       NULL,
    [TASKSWOOREST]   SMALLINT       NULL,
    [TASKSWOREMHRS]  SMALLINT       NULL,
    [TASKSUNASS]     SMALLINT       NULL,
    [CTWOCOMPHRS]    SMALLINT       NULL,
    [DEVTASKSWOCS]   SMALLINT       NULL,
    [DATE]           DATE           NULL,
    [SUBSCRIPTIONID] NVARCHAR (MAX) NULL,
    [ORIGINALEST]    INT            NULL,
    [REMAININGHRS]   INT            NULL,
    [COMPLETEDHRS]   INT            NULL
);

