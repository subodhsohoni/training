﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
// https://www.nuget.org/packages/Microsoft.TeamFoundationServer.Client/
using Microsoft.TeamFoundation.WorkItemTracking.WebApi;
using Microsoft.TeamFoundation.WorkItemTracking.WebApi.Models;

// https://www.nuget.org/packages/Microsoft.VisualStudio.Services.InteractiveClient/
using Microsoft.VisualStudio.Services.Client;

// https://www.nuget.org/packages/Microsoft.VisualStudio.Services.Client/
using Microsoft.VisualStudio.Services.Common;
using Microsoft.TeamFoundation.SourceControl.WebApi;
using System.Data.SqlClient;
using System.Data;
using Microsoft.TeamFoundation.Core.WebApi.Types;
using Microsoft.TeamFoundation.Work.WebApi;
using Microsoft.VisualStudio.Services.WebApi;
using System.IO;

namespace VSTSClient
{
    class Program
    {

        static void Main(string[] args)
        {
            if (System.DateTime.Today.DayOfWeek != DayOfWeek.Saturday && System.DateTime.Today.DayOfWeek != DayOfWeek.Sunday)
            {
                Task theTask = DoGetWorkItems();
                theTask.Wait();
            }
        }

        public static async Task DoGetWorkItems()
        {
            try
            {
                await GetWorkItems();
            }
            catch (Exception ex)
            {
                sw.WriteLine("Exception:" + ex.Message + " Inner Exception:" + ex.InnerException.Message);
            }
        }
        static bool CalledFromRoot = true;
        static string CurrentIteration = "";
        static string CurrentArea = "", TargetArea = "";
        static bool CurrentIterationFound = false;
        static string project = "";
        static string SubscriptionId = "";
        static string pat = "";
        static double OriginalEst = 0;
        static double RemainingHrs = 0;
        static double CompletedHrs = 0;
        static string ConStr = "Server=tcp:vstsdb.database.windows.net,1433;Initial Catalog=VSTSDashboard;Persist Security Info=False;User ID=vsts;Password=P2ssw0rd; MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        static string LogFile = ".\\logfile.txt";
        static StreamWriter sw = new StreamWriter(LogFile); 
        private static async Task GetWorkItems()
        {
            //From the Projects table get the Project Name, Subscription Ids and PAT for each of them
            SqlConnection con = new SqlConnection(ConStr);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "SELECT * FROM Projects";
            con.Open();
            SqlDataReader drP = cmd.ExecuteReader();
            List<string> PatList = new List<string>();
            List<string> ProjList = new List<string>();
            List<string> SubscrList = new List<string>();
            while (drP.Read())
            {
                PatList.Add(drP["PAT"].ToString());
                ProjList.Add(drP["ProjectName"].ToString());
                SubscrList.Add(drP["SubscriptionId"].ToString());
            }
            con.Close();
            
            // Create instance of VssConnection using Personal Access Token
           
            for (int i = 0; i < ProjList.Count; i++)
            {
                // If you want to store area wise information then uncomment this code and comment the next line.
                //TargetArea = ProjList[i];
                //if (TargetArea.Contains('/'))
                //{
                //    TargetArea = TargetArea.Replace(" / ", "\\");
                //}
                //if (ProjList[i].Contains('/'))
                //{
                //    project = ProjList[i].Substring(0, ProjList[i].IndexOf('/') - 1);
                //}
                //else
                //{
                //    project = ProjList[i];
                //}
                project = ProjList[i];
                SubscriptionId = SubscrList[i];
                pat = PatList[i];
                CurrentIteration = project;
                CurrentIterationFound = false;
                CurrentArea = project;
                try
                {
                    VssConnection connection = new VssConnection(new Uri("https://" + SubscriptionId + ".visualstudio.com"), new VssBasicCredential(string.Empty, pat));
                    
                    WorkItemTrackingHttpClient witClient = connection.GetClient<WorkItemTrackingHttpClient>();
                    
                    var rootIteration = witClient.GetClassificationNodeAsync(project, TreeStructureGroup.Iterations, depth: int.MaxValue).Result;
                    //Following function will get current iteration from dates set for each iteration. Please ensure that dates are set.
                    GetCurrentIteration(project, witClient, rootIteration);
                    if (!CurrentIterationFound)
                    {
                        sw.WriteLine("Current Iteration not found for project " + project + ". Please set dates to iterations and run the program again");
                        continue;
                    }
                    sw.WriteLine("Current Iteration: " + CurrentIteration);

                    var RootArea = witClient.GetClassificationNodeAsync(project, TreeStructureGroup.Areas, depth: int.MaxValue).Result;
                    
                    CalculateStats(project, witClient, RootArea);
                    sw.WriteLine("Processed data for project: " + project);
                    
                }
                catch (Exception ex)
                {
                    sw.WriteLine("Exception:" + ex.Message);
                    continue;
                }

            }
            sw.Flush();
            sw.Close();
        }

        private static void CalculateStats(string project, WorkItemTrackingHttpClient witClient, WorkItemClassificationNode Area)
        {
            
            if (CurrentArea == TargetArea)
            { 
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                int OpenReq = 0; int OpenReqWOAccCriteria = 0; int RequirementsWOLinkedTasks = 0; int TasksWOLinkedRequirements = 0; int AllOpenTasks = 0; int TasksWithoutOriginalEstimate = 0; int TasksWithoutRemainingHours = 0; int UnassignedTasks = 0; int AllClosedTasks = 0; int DevTasksNotLinkedToChangeset = 0; int TasksWithoutCompletedHours = 0; int TasksWithoutChangesInRemainingHours = 0;

                Wiql wiql = new Wiql();
                int areaId = 0;
                if (CalledFromRoot)
                {
                    areaId = Area.Id - 4;
                }
                else
                {
                    areaId = Area.Id;
                }

                wiql.Query = "SELECT [System.Id] FROM WorkItems WHERE [System.TeamProject] = '" + project + "'  AND  [System.WorkItemType] IN GROUP 'Requirement Category' AND [System.IterationPath] UNDER '" + CurrentIteration + "'";

                WorkItemQueryResult result = witClient.QueryByWiqlAsync(wiql).Result;

                if (result.WorkItems.Any())
                {

                    //const int batchSize = 100;
                    IEnumerable<WorkItemReference> workItemRefs;
                    workItemRefs = result.WorkItems;

                    List<WorkItem> workItemsList = witClient.GetWorkItemsAsync(workItemRefs.Select(wir => wir.Id)).Result;
                    OpenReq = workItemsList.Count;
                }
               

                #region All open requirements and open requirements without acceptance criteria
                wiql.Query = "SELECT [System.Id] FROM WorkItems WHERE [System.TeamProject] = '" + project + "'  AND  [System.WorkItemType] IN GROUP 'Requirement Category' AND [System.AreaPath] UNDER '" + CurrentArea + "' AND [System.IterationPath] UNDER '" + CurrentIteration + "' AND ([System.State] <> 'Closed' OR [System.State] <> 'Completed')";

        //WorkItemQueryResult result = witClient.QueryByWiqlAsync(wiql).Result;

        if (result.WorkItems.Any())
        {

            //const int batchSize = 100;
            IEnumerable<WorkItemReference> workItemRefs;
            workItemRefs = result.WorkItems;

            List<WorkItem> workItemsList = witClient.GetWorkItemsAsync(workItemRefs.Select(wir => wir.Id)).Result;
            OpenReq = workItemsList.Count;
            sw.WriteLine("Total open requirements :" + workItemsList.Count);
            OpenReqWOAccCriteria = workItemsList.Count;

            foreach (WorkItem wi in workItemsList)
            {
                int _id = wi.Id ?? default(int);
                IEnumerable<string> fields = new List<string>() { "Microsoft.VSTS.Common.AcceptanceCriteria" };
                WorkItem workItem = witClient.GetWorkItemAsync(_id, fields, null, null).Result;
                if (workItem.Fields.Count == 1)
                {
                    OpenReqWOAccCriteria--;
                }
            }
            sw.WriteLine("Open requirements without acceptance criteria:" + OpenReqWOAccCriteria);
        }
        else
        {
            sw.WriteLine("Total open work items : 0");
            sw.WriteLine("Open requirements without acceptance criteria: 0");
        }
        #endregion
                #region Requirements without linked Tasks
        wiql.Query = "SELECT [System.Id], [System.WorkItemType], [System.Title], [System.AssignedTo], [System.State], [System.Tags] FROM WorkItemLinks WHERE ([Source].[System.TeamProject] = '" + project + "' AND  [Source].[System.WorkItemType] IN GROUP 'Requirement Category') AND [Source].[System.IterationPath] UNDER '" + CurrentIteration + "' AND [Source].[System.AreaPath] UNDER '" + CurrentArea + "' And ([System.Links.LinkType] <> '') And ([Target].[System.TeamProject] = '" + project + "'  AND  [Target].[System.WorkItemType] = 'Task')  mode(DoesNotContain)";
        WorkItemQueryResult requirements = witClient.QueryByWiqlAsync(wiql).Result;
        if (requirements.WorkItems.Any())
        {
            IEnumerable<WorkItemReference> requirementsRefs;
            requirementsRefs = requirements.WorkItems;

            List<WorkItem> tasksList = witClient.GetWorkItemsAsync(requirementsRefs.Select(wir => wir.Id)).Result;
            RequirementsWOLinkedTasks = tasksList.Count;


            sw.WriteLine("Requirements without linked Tasks:" + RequirementsWOLinkedTasks);
        }
        else
        {
            sw.WriteLine("Requirements without linked Tasks: 0");
        }

        #endregion
                #region Orphan Tasks
        wiql.Query = "SELECT [System.Id], [System.WorkItemType], [System.Title], [System.AssignedTo], [System.State], [System.Tags] FROM WorkItemLinks WHERE ([Source].[System.TeamProject] = '" + project + "' AND  [Source].[System.WorkItemType] = 'Task' ) AND [Source].[System.IterationPath] UNDER '" + CurrentIteration + "' AND [Source].[System.AreaPath] UNDER '" + CurrentArea + "' And ([System.Links.LinkType] <> '') And ([Target].[System.TeamProject] = '" + project + "'  AND  [Target].[System.WorkItemType] IN GROUP 'Requirement Category')  mode(DoesNotContain)";
        WorkItemQueryResult AllTasks = witClient.QueryByWiqlAsync(wiql).Result;
        if (AllTasks.WorkItems.Any())
        {
            IEnumerable<WorkItemReference> TaskRefs;
            TaskRefs = AllTasks.WorkItems;

            try
            {
                List<WorkItem> reqList = witClient.GetWorkItemsAsync(TaskRefs.Select(wir => wir.Id)).Result;
                TasksWOLinkedRequirements = reqList.Count;
            }
            catch
            {
                sw.WriteLine("Orphan Tasks:" + TasksWOLinkedRequirements);
            }
        }
        else
        {
            sw.WriteLine("Orphan Tasks: 0");
        }

        #endregion
                #region Open tasks, tasks without original estimate, remaining hours and unassigned tasks

        wiql.Query = "SELECT [System.Id], [Microsoft.VSTS.Scheduling.OriginalEstimate] FROM WorkItems WHERE [System.WorkItemType] = 'Task' AND [System.State] <> 'Closed' AND [System.TeamProject]='" + project + "' AND [System.AreaPath] UNDER '" + CurrentArea + "' AND [System.IterationPath] UNDER '" + CurrentIteration + "'";
        WorkItemQueryResult tasks = witClient.QueryByWiqlAsync(wiql).Result;
        if (tasks.WorkItems.Any())
        {
            IEnumerable<WorkItemReference> tasksRefs;
            tasksRefs = tasks.WorkItems;

            List<WorkItem> tasksList = witClient.GetWorkItemsAsync(tasksRefs.Select(wir => wir.Id)).Result;
            AllOpenTasks = tasksList.Count;


            foreach (WorkItem task in tasksList)
            {
                int _id = task.Id ?? default(int);
                IEnumerable<string> fields = new List<string>() { "Microsoft.VSTS.Scheduling.OriginalEstimate", "System.AssignedTo", "Microsoft.VSTS.Scheduling.RemainingWork", "Microsoft.VSTS.Scheduling.CompletedWork" };
                WorkItem workItem = witClient.GetWorkItemAsync(_id, fields, null, null).Result;
                bool FoundTaskWithOriginalEstimate = false, FoundTaskWithAssignedTo = false, FoundTaskWithRemainingHours = false;
                if (workItem.Fields.Count > 0)
                {
                    foreach (string fld in workItem.Fields.Keys.ToList<string>())
                    {
                        if (fld == "Microsoft.VSTS.Scheduling.OriginalEstimate")
                        {
                            FoundTaskWithOriginalEstimate = true;
                            OriginalEst += (double)workItem.Fields[fld];
                        }
                        if (fld == "System.AssignedTo")
                        {
                            FoundTaskWithAssignedTo = true;
                        }
                        if (fld == "Microsoft.VSTS.Scheduling.RemainingWork")
                        {
                            FoundTaskWithRemainingHours = true;
                            RemainingHrs += (double)workItem.Fields[fld];
                        }

                    }
                    //List<WorkItem> TaskRev = witClient.GetRevisionsAsync(_id).Result;
                       
                    //for (int i = TaskRev.Count; i >= 1; i--)
                    //{
                    //    var rev = TaskRev[i];
                    //    var prevRev = TaskRev[i - 1];
                    //    sw.WriteLine(rev.Fields["Microsoft.VSTS.Scheduling.RemainingWork"].ToString());
                    //    foreach (var fld in rev.Fields)
                    //    {
                    //        sw.WriteLine(fld.Key + ":" + fld.Value);
                    //    }
                    //}
                    if (!FoundTaskWithOriginalEstimate)
                    {
                        TasksWithoutOriginalEstimate++;
                    }
                    if (!FoundTaskWithAssignedTo)
                    {
                        UnassignedTasks++;
                    }
                    if (!FoundTaskWithRemainingHours)
                    {
                        TasksWithoutRemainingHours++;
                    }
                }
            }
            sw.WriteLine("Total number of Open Tasks:" + AllOpenTasks);
            sw.WriteLine("Tasks without original estimate:" + TasksWithoutOriginalEstimate);
            sw.WriteLine("Tasks without remaining hours:" + TasksWithoutOriginalEstimate);
            sw.WriteLine("Unassigned Tasks:" + UnassignedTasks);
        }
        else
        {
            sw.WriteLine("Total number of Open Tasks: 0");
            sw.WriteLine("Tasks without original estimate: 0");
            sw.WriteLine("Tasks without remaining hours: 0");
            sw.WriteLine("Unassigned Tasks: 0");
        }
        #endregion
                #region Closed tasks without completed hours

        wiql.Query = "SELECT [System.Id], [Microsoft.VSTS.Scheduling.CompletedWork], [Microsoft.VSTS.Common.Activity], [System.ExternalLinkCount] FROM WorkItems WHERE [System.WorkItemType] = 'Task' AND [System.State] = 'Closed' AND [System.TeamProject]='" + project + "' AND [System.AreaPath] UNDER '" + CurrentArea + "' AND [System.IterationPath] UNDER '" + CurrentIteration + "'";
        tasks = witClient.QueryByWiqlAsync(wiql).Result;
        if (tasks.WorkItems.Any())
        {
            IEnumerable<WorkItemReference> tasksRefs;
            tasksRefs = tasks.WorkItems;
            List<WorkItem> tasksList = null;
            try
            {
                tasksList = witClient.GetWorkItemsAsync(tasksRefs.Select(wir => wir.Id)).Result;
                AllClosedTasks = tasksList.Count;
                foreach (WorkItem task in tasksList)
                {
                    int _id = task.Id ?? default(int);
                    IEnumerable<string> fields = new List<string>() { "Microsoft.VSTS.Scheduling.CompletedWork" };
                    WorkItem workItem = witClient.GetWorkItemAsync(_id, fields, null, null).Result;
                    if (workItem.Fields.Count == 0)
                    {
                        TasksWithoutCompletedHours++;
                    }
                    else
                    {
                        foreach (string fld in workItem.Fields.Keys.ToList<string>())
                        {
                            if (fld == "Microsoft.VSTS.Scheduling.CompletedWork")
                            {
                                CompletedHrs += (double)workItem.Fields[fld];
                            }
                        }
                    }
                }
                
                sw.WriteLine("Closed Development Tasks without completed hours:" + TasksWithoutCompletedHours);
                bool FoundTaskLinkedToChangeset = false;
                foreach (WorkItem task in tasksList)
                {
                    int _id = task.Id ?? default(int);
                    IEnumerable<string> fields = new List<string>() { "Microsoft.VSTS.Common.Activity", "System.ExternalLinkCount"};
                    WorkItem workItem = witClient.GetWorkItemAsync(_id, fields, null,null).Result;
                    if (workItem.Fields.Count > 1 && task.Fields["Microsoft.VSTS.Common.Activity"].ToString() == "Development")
                    {
                        var rels = workItem.Relations;
                        if (rels != null)
                        {
                            foreach (WorkItemRelation rel in rels)
                            {
                                if (rel.Url.Contains("Changeset"))
                                {
                                    FoundTaskLinkedToChangeset = true;
                                    break;
                                }
                            }
                        }
                        if (!FoundTaskLinkedToChangeset)
                        {
                            DevTasksNotLinkedToChangeset++;
                        }
                    }
                }
                sw.WriteLine("Closed Development Tasks without linked changeset:" + DevTasksNotLinkedToChangeset);
            }
            catch (Exception ex)
            {

            }
        }
        else
        {
            sw.WriteLine("Closed Tasks without Completed Hours: 0");
            sw.WriteLine("Closed Development Tasks without linked changeset: 0");
        }
            #endregion
                #region Open tasks for which remaining hours are not changed today or yesterday

            wiql.Query = "SELECT [System.Id], [Microsoft.VSTS.Scheduling.RemainingWork], [Microsoft.VSTS.Common.Activity], [System.ExternalLinkCount] FROM WorkItems WHERE [System.WorkItemType] = 'Task' AND [System.State] <> 'Closed' AND [System.TeamProject]='" + project + "' AND [System.AreaPath] UNDER '" + CurrentArea + "' AND [System.IterationPath] UNDER '" + CurrentIteration + "' AND [System.ChangedDate] >= @today - 1";
            tasks = witClient.QueryByWiqlAsync(wiql).Result;
            if (tasks.WorkItems.Any())
            {
                IEnumerable<WorkItemReference> tasksRefs;
                tasksRefs = tasks.WorkItems;
                List<WorkItem> tasksList = null;
                try
                {
                    tasksList = witClient.GetWorkItemsAsync(tasksRefs.Select(wir => wir.Id)).Result;
                    AllOpenTasks = tasksList.Count;
                    foreach (WorkItem task in tasksList)
                    {
                        int _id = task.Id ?? default(int);
                        IEnumerable<string> fields = new List<string>() { "Microsoft.VSTS.Scheduling.RemainingWork" };
                        WorkItem workItem = witClient.GetWorkItemAsync(_id, fields, null, null).Result;
                        if (workItem.Fields.Count == 0)
                        {
                            TasksWithoutChangesInRemainingHours++;
                            //sw.WriteLine(workItem.Id);
                        }
                        //else
                        //{
                        //    foreach (string fld in workItem.Fields.Keys.ToList<string>())
                        //    {
                        //        if (fld == "Microsoft.VSTS.Scheduling.CompletedWork")
                        //        {
                        //            CompletedHrs += (double)workItem.Fields[fld];
                        //        }
                        //    }
                        //}
                    }

                    //sw.WriteLine("Closed Development Tasks without completed hours:" + TasksWithoutCompletedHours);
                    //bool FoundTaskLinkedToChangeset = false;
                    wiql.Query = "SELECT [System.Id], [Microsoft.VSTS.Scheduling.RemainingWork], [Microsoft.VSTS.Common.Activity], [System.ExternalLinkCount] FROM WorkItems WHERE [System.WorkItemType] = 'Task' AND [System.State] <> 'Closed' AND [System.TeamProject]='" + project + "' AND [System.AreaPath] UNDER '" + CurrentArea + "' AND [System.IterationPath] UNDER '" + CurrentIteration + "' AND [System.ChangedDate] < @today - 1";
                    tasks = witClient.QueryByWiqlAsync(wiql).Result;
                    if (tasks.WorkItems.Any())
                    {
                        tasksRefs = tasks.WorkItems;
                        try
                        {
                            tasksList = witClient.GetWorkItemsAsync(tasksRefs.Select(wir => wir.Id)).Result;
                            
                            foreach (WorkItem task in tasksList)
                            {
                                int _id = task.Id ?? default(int);
                                sw.WriteLine(task.Id);
                            }
                        }
                        catch
                        { }
                    }
                    //sw.WriteLine("Closed Development Tasks without linked changeset:" + DevTasksNotLinkedToChangeset);
                }
                catch (Exception ex)
                {

                }
            }
            else
            {
                sw.WriteLine("Closed Tasks without Completed Hours: 0");
                sw.WriteLine("Closed Development Tasks without linked changeset: 0");
            }
            #endregion
                con.ConnectionString = ConStr;
                cmd.CommandText = "SELECT * FROM ComplianceData WHERE SUBSCRIPTIONID='" + SubscriptionId + "' AND PROJNAME = @PROJECT AND DATE = @DATE AND AREA= @AREA";
                cmd.Parameters.AddWithValue("@PROJECT", SqlDbType.NVarChar).Value = project;
                cmd.Parameters.AddWithValue("@DATE", SqlDbType.Date).Value = System.DateTime.Today;
                cmd.Parameters.AddWithValue("@AREA", SqlDbType.NVarChar).Value = CurrentArea;
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    con.Close();
                    return;
                }
                else
                {
                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                    cmd.CommandText = "INSERT INTO ComplianceData VALUES (@PROJNAME, @ITERATION, @AREA1, @OPENREQ, @ORWOACCCR, @ORWOTASKS, @OPENTASKS, @ORPHANS, @TASKSWOOREST, @TASKSWOREMHRS, @TASKSUNASS, @CTWOCOMPHRS, @DEVTASKSWOCS, @DATE1, @SUBSCRIPTIONID, @ORIGINALEST, @REMAININGHRS, @COMPLETEDHRS)";
                    cmd.Parameters.Add("@PROJNAME", SqlDbType.NVarChar).Value = project;
                    cmd.Parameters.AddWithValue("@ITERATION", SqlDbType.NVarChar).Value = CurrentIteration;
                    cmd.Parameters.AddWithValue("@AREA1", SqlDbType.NVarChar).Value = CurrentArea;
                    cmd.Parameters.AddWithValue("@OPENREQ", SqlDbType.SmallInt).Value = OpenReq;
                    cmd.Parameters.AddWithValue("@ORWOACCCR", SqlDbType.SmallInt).Value = OpenReqWOAccCriteria;
                    cmd.Parameters.AddWithValue("@ORWOTASKS", SqlDbType.SmallInt).Value = RequirementsWOLinkedTasks;
                    cmd.Parameters.AddWithValue("@OPENTASKS", SqlDbType.SmallInt).Value = AllOpenTasks;
                    cmd.Parameters.AddWithValue("@ORPHANS", SqlDbType.SmallInt).Value = TasksWOLinkedRequirements;
                    cmd.Parameters.AddWithValue("@TASKSWOOREST", SqlDbType.SmallInt).Value = TasksWithoutOriginalEstimate;
                    cmd.Parameters.AddWithValue("@TASKSWOREMHRS", SqlDbType.SmallInt).Value = TasksWithoutRemainingHours;
                    cmd.Parameters.AddWithValue("@TASKSUNASS", SqlDbType.SmallInt).Value = UnassignedTasks;
                    cmd.Parameters.AddWithValue("@CTWOCOMPHRS", SqlDbType.SmallInt).Value = TasksWithoutCompletedHours;
                    cmd.Parameters.AddWithValue("@DEVTASKSWOCS", SqlDbType.SmallInt).Value = DevTasksNotLinkedToChangeset;
                    cmd.Parameters.AddWithValue("@DATE1", SqlDbType.Date).Value = System.DateTime.Today.ToString("MM-dd-yyyy");
                    cmd.Parameters.AddWithValue("@SUBSCRIPTIONID", SqlDbType.NVarChar).Value = SubscriptionId;
                    cmd.Parameters.AddWithValue("@ORIGINALEST", SqlDbType.Int).Value = OriginalEst;
                    cmd.Parameters.AddWithValue("@REMAININGHRS", SqlDbType.Int).Value = RemainingHrs;
                    cmd.Parameters.AddWithValue("@COMPLETEDHRS", SqlDbType.Int).Value = CompletedHrs;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        private static void ProcessAreas(string project, WorkItemTrackingHttpClient witClient, WorkItemClassificationNode Area)
        {
            if (Area.Name.ToUpper() != CurrentArea.ToUpper())
            {
                CurrentArea += "\\" + Area.Name;
            }
           
            sw.WriteLine("\n" + CurrentArea);
            CalculateStats(project, witClient, Area);
            if (Area.Children != null)
            {
                foreach (var child in Area.Children)
                {                   
                    ProcessAreas(project, witClient, child);
                }

            }
            if (CurrentArea != project)
            CurrentArea = CurrentArea.Substring(0, CurrentArea.LastIndexOf("\\"));
        }
        private static void GetCurrentIteration(string project, WorkItemTrackingHttpClient witClient, WorkItemClassificationNode Iteration)
        {
            //sw.WriteLine(Iteration.Name);
            if (Iteration.Attributes != null && Iteration.Children == null)
            {
                object startDateValue;
                object finishDateValue;
                Iteration.Attributes.TryGetValue("startDate", out startDateValue);
                Iteration.Attributes.TryGetValue("finishDate", out finishDateValue);
                var startDate = startDateValue as DateTime?;
                var finishDate = finishDateValue as DateTime?;
                if (startDate.HasValue && finishDate.HasValue)
                {
                    if (startDate <= System.DateTime.Now && System.DateTime.Now <= finishDate)
                    {
                        CurrentIteration += "\\" + Iteration.Name;
                        CurrentIterationFound = true;
                        return;
                    }
                }
            }
            if (Iteration.Children != null)
            {
                if (Iteration.Name.ToUpper() != CurrentIteration.ToUpper())
                {
                    CurrentIteration += "\\" + Iteration.Name;
                }
                foreach (var child in Iteration.Children)
                {                    
                    if (!CurrentIterationFound)
                        GetCurrentIteration(project, witClient, child);
                }
                if (CurrentIterationFound) return;
                if (CurrentIteration != project)
                {
                    CurrentIteration = CurrentIteration.Substring(0, CurrentIteration.LastIndexOf("\\"));
                }
            }            
        }
    }
}
//comment for demo